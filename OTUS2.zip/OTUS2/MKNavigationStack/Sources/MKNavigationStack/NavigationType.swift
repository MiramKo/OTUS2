//
//  NavigationType.swift
//  OTUS2
//
//  Created by Михаил Костров on 07.05.2023.
//

import Foundation

enum NavigationType {
    case pop
    case push
}
