openapi-generator generate -i "specs.yaml" --reserved-words-mappings Character=chdf -g swift5 -o "api-mobile"
