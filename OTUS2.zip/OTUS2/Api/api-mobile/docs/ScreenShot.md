# ScreenShot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int** |  | [optional] [readonly] 
**image** | **String** | An image file with size up to 20 MB. | [optional] [readonly] 
**hidden** | **Bool** | Set image as hidden or visible. | [optional] [default to false]
**width** | **Int** |  | [optional] [readonly] 
**height** | **Int** |  | [optional] [readonly] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


