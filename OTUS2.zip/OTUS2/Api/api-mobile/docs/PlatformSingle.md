# PlatformSingle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int** |  | [optional] [readonly] 
**name** | **String** |  | 
**slug** | **String** |  | [optional] [readonly] 
**gamesCount** | **Int** |  | [optional] [readonly] 
**imageBackground** | **String** |  | [optional] [readonly] 
**description** | **String** |  | [optional] 
**image** | **String** |  | [optional] [readonly] 
**yearStart** | **Int** |  | [optional] 
**yearEnd** | **Int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


