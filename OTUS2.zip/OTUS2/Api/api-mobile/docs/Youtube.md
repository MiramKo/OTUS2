# Youtube

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int** |  | [optional] [readonly] 
**externalId** | **String** |  | [optional] [readonly] 
**channelId** | **String** |  | [optional] [readonly] 
**channelTitle** | **String** |  | [optional] [readonly] 
**name** | **String** |  | [optional] [readonly] 
**description** | **String** |  | [optional] [readonly] 
**created** | **Date** |  | [optional] [readonly] 
**viewCount** | **Int** |  | [optional] [readonly] 
**commentsCount** | **Int** |  | [optional] [readonly] 
**likeCount** | **Int** |  | [optional] [readonly] 
**dislikeCount** | **Int** |  | [optional] [readonly] 
**favoriteCount** | **Int** |  | [optional] [readonly] 
**thumbnails** | **AnyCodable** |  | [optional] [readonly] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


