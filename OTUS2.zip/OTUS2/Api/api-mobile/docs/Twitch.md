# Twitch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int** |  | [optional] [readonly] 
**externalId** | **Int** |  | [optional] [readonly] 
**name** | **String** |  | [optional] [readonly] 
**description** | **String** |  | [optional] [readonly] 
**created** | **Date** |  | [optional] [readonly] 
**published** | **Date** |  | [optional] [readonly] 
**thumbnail** | **String** |  | [optional] [readonly] 
**viewCount** | **Int** |  | [optional] [readonly] 
**language** | **String** |  | [optional] [readonly] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


