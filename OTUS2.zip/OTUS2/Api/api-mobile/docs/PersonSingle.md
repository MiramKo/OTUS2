# PersonSingle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int** |  | [optional] [readonly] 
**name** | **String** |  | 
**slug** | **String** |  | [optional] [readonly] 
**image** | **String** |  | [optional] [readonly] 
**imageBackground** | **String** |  | [optional] [readonly] 
**description** | **String** |  | [optional] 
**gamesCount** | **Int** |  | [optional] [readonly] 
**reviewsCount** | **Int** |  | [optional] [readonly] 
**rating** | **Decimal** |  | [optional] [readonly] 
**ratingTop** | **Int** |  | [optional] [readonly] 
**updated** | **Date** |  | [optional] [readonly] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


