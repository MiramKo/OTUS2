# Reddit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int** |  | [optional] [readonly] 
**name** | **String** |  | [optional] [readonly] 
**text** | **String** |  | [optional] [readonly] 
**image** | **String** |  | [optional] [readonly] 
**url** | **String** |  | [optional] [readonly] 
**username** | **String** |  | [optional] [readonly] 
**usernameUrl** | **String** |  | [optional] [readonly] 
**created** | **Date** |  | [optional] [readonly] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


