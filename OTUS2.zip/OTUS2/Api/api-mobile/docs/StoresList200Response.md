# StoresList200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Int** |  | 
**next** | **String** |  | [optional] 
**previous** | **String** |  | [optional] 
**results** | [Store] |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


