# Person

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Int** |  | [optional] [readonly] 
**name** | **String** |  | 
**slug** | **String** |  | [optional] [readonly] 
**image** | **String** |  | [optional] [readonly] 
**imageBackground** | **String** |  | [optional] [readonly] 
**gamesCount** | **Int** |  | [optional] [readonly] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


