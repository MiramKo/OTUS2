//
//  OTUS2App.swift
//  OTUS2
//
//  Created by Михаил Костров on 07.05.2023.
//

import SwiftUI

@main
struct OTUS2App: App {
    var body: some Scene {
        WindowGroup {
            RootAppView()
        }
    }
}
